#include<stdio.h>
#include<unistd.h>
int var=10;
int main()
{
        pid_t fork_val;
        fork_val=fork();
        if(fork_val<0){

                printf("failed to create\n");
        }
        else if(fork_val==0)
        {
                printf("hello I am child, my id is %d\n",getpid());
                var=20;
                 printf("Var=%d\n",var);
                //char *args[]={"./helow",NULL};
                //execv(args[0],args);
                sleep(30);
        }
        else
        {
                wait();
          printf("hello I am parent, my id is %d\n",getpid());
          printf("Var=%d\n",var);
          sleep(50);
        }
}
