#include<stdio.h>
#include <sys/types.h>
#include <unistd.h>

int main()
{
        printf("hello fork");
	printf("My process id :%d , %d",getpid(),getppid());
        fork();
        printf("hey fork\n");
        printf("hello fork");
        printf("My process id :%d , %d",getpid(),getppid());
        fork();

        getchar();
}
