#include<stdio.h>
#include <sys/types.h>
#include <unistd.h>

int main()
{
	int pid;
	printf("before pid %d \n",getpid());
	pid = fork();
	printf("%d,pid \n",pid);
	printf("%d pid\n",getpid());
	getchar();
}
