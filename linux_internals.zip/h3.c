/*#include<stdio.h>
#include <sys/types.h>
#include <unistd.h>
int global;
int main()
{
	global =5;
	int pid;

         //pid_t  fork_val;
	 //fork_val = fork();

        //if (fork_val < 0)
        //{
        //printf("failed to create a child");
        //}
	 if (pid == 0)
        {
		global =10;
        printf("I am in child process id is %d\n",getpid());
	sleep(20);
	//char *args[] = {"./h2",NULL};
	//execv(args[0],args);
	//sleep;
        }
	else
               {		
		printf("i am parent , my id is %d\n ",getpid());
		sleep(50);
	}
        getchar();
}
*/

#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>
 //#include <sys/wait.h>

int d;
int main()
{
	int child_state;
        d=5;
        pid_t fork_val;
        fork_val=fork();

        //if(fork_val<0)
        //{
        //      printf("fail tyo create child\n");
        //}
        if(fork_val==0)
        {

       
                printf("i am in child my id is %d\n",getpid());
		printf("%d",d);
		wait(&child_state);
                sleep(20);
                //char *args[]={"./hello",NULL};
                //execv(args[0],args);
        }
        else
        {
                printf("i am saswat my id is %d\n",getpid());
		printf("%d",d);
		wait(&child_state);
                   sleep(50);

        }
}
