#include<stdio.h>
int main()
{
        printf("I AM SWADHIN MY ID IS %d",getpid());

}
