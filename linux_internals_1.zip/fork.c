#include<stdio.h>
#include <sys/types.h>
#include <unistd.h>

int main()
{
        int pid;
	 pid = fork();

	if ((pid = fork())>0)
	{
        printf("HEllo from the child");
	}
	else
	{
        printf("hello from the parent");
	}
	getchar();
}
