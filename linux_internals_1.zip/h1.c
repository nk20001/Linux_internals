#include<stdio.h>

int main()
{

       // char *args[]={"./h2",NULL};
       char *file = "ls";
       char *arg1 = "-a";
       char *arg2 = "-s";
        printf("hi i am saswat,my id is %d\n",getpid());
        execlp(file,arg1,arg2);
        printf("hello i am nikita\n");
}
